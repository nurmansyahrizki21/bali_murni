    <!-- harga beli otomatis -->
    <script type="text/javascript">
            <?php echo $beli; ?>
    </script>

    <!-- harga jual otomatis -->
    <script type="text/javascript">
            <?php echo $jual; ?>
    </script>
    
    <!-- total harga beli otomatis -->
    <script>
        $("#jumlah_beli").keyup(function(){
            total = $("#jumlah_beli").val() * $("#harga_beli").val();
            hasil = total.toFixed(2);
            $("#total_harga").val(hasil);
        });

        $("#harga_beli").keyup(function(){
            total = $("#jumlahbeli").val() * $("#harga_beli").val();
            hasil = total.toFixed(2);
            $("#total_harga").val(hasil);
        });
    </script>

     <!-- total harga jual otomatis -->
     <script>
        $("#jumlah_jual").keyup(function(){
            total = $("#jumlah_jual").val() * $("#harga_jual").val();
            hasil = total.toFixed(2);
            $("#total_harga_jual").val(hasil);
        });

        $("#harga_jual").keyup(function(){
            total = $("#jumlah_jual").val() * $("#harga_jual").val();
            hasil = total.toFixed(2);
            $("#total_harga_jual").val(hasil);
        });
    </script>

    <!-- Insert Modal Tanpa Reload , CO -->
    <script type="text/javascript">
        $(document).ready(function(){
            $("#Submit").click(function(){
                var data = $('#form').serialize();
                $.ajax({
                    type	: 'POST',
                    url	: "co/fungsi/tambah_tmp.php",
                    data: data,

                    cache	: false,
                    success	: function(data){
                        $('#tampil').load("co/tampil.php");
                    }
                });
            });
        });
    </script>

    <script>
        // ini menyiapkan dokumen agar siap grak :)
        $(document).ready(function(){
            // yang bawah ini bekerja jika tombol lihat data (class="view_data") di klik
            $('.view_data').click(function(){
                // membuat variabel id, nilainya dari attribut id pada button
                // id="'.$row['id'].'" -> data id dari database ya sob, jadi dinamis nanti id nya
                var id = $(this).attr("id_co");
                var tgl = $(this).attr("tgl");
                var nama_pelanggan = $(this).attr("nama_pelanggan");
                
                // memulai ajax
                $.ajax({
                    url: 'co/detail_query.php',	// set url -> ini file yang menyimpan query tampil detail data siswa
                    method: 'post',		// method -> metodenya pakai post. Tahu kan post? gak tahu? browsing aja :)
                    data: {id:id, tgl:tgl, nama_pelanggan:nama_pelanggan},		// nah ini datanya -> {id:id} = berarti menyimpan data post id yang nilainya dari = var id = $(this).attr("id");
                    success:function(data){		// kode dibawah ini jalan kalau sukses
                        $('#data_detail').html(data);	// mengisi konten dari -> <div class="modal-body" id="data_siswa">
                        $('#details').modal("show");	// menampilkan dialog modal nya
                    }
                });
            });
        });
    </script>


    <!-- Insert Modal Tanpa Reload , PO -->
    <script type="text/javascript">
        $(document).ready(function(){
            $("#Submit_po").click(function(){
                var data = $('#form_po').serialize();
                $.ajax({
                    type	: 'POST',
                    url	: "po/fungsi/tambah_tmp.php",
                    data: data,

                    cache	: false,
                    success	: function(data){
                        $('#tampil').load("po/tampil.php");
                    }
                });
            });
        });
    </script>

    <script>
        // ini menyiapkan dokumen agar siap grak :)
        $(document).ready(function(){
            // yang bawah ini bekerja jika tombol lihat data (class="view_data") di klik
            $('.view_data_po').click(function(){
                // membuat variabel id, nilainya dari attribut id pada button
                // id="'.$row['id'].'" -> data id dari database ya sob, jadi dinamis nanti id nya
                var id = $(this).attr("id_po");
                var tgl = $(this).attr("tgl");
                
                // memulai ajax
                $.ajax({
                    url: 'po/detail_query.php',	// set url -> ini file yang menyimpan query tampil detail data siswa
                    method: 'post',		// method -> metodenya pakai post. Tahu kan post? gak tahu? browsing aja :)
                    data: {id:id, tgl:tgl},		// nah ini datanya -> {id:id} = berarti menyimpan data post id yang nilainya dari = var id = $(this).attr("id");
                    success:function(data){		// kode dibawah ini jalan kalau sukses
                        $('#data_detail_po').html(data);	// mengisi konten dari -> <div class="modal-body" id="data_po">
                        $('#detail_po').modal("show");	// menampilkan dialog modal nya
                    }
                });
            });
        });
    </script>
