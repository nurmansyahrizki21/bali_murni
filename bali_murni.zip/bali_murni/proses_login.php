<html>
    <head>
    <script src="plugins/sweetalert/sweetalert.all.min.js"></script>
    <link rel='stylesheet' href='plugins/sweetalert/sweetalert.min.css'>
    </head>
    <body>
<?php 
include 'user/config/koneksi.php';
if(isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $login = mysqli_query($conn,"SELECT * FROM user WHERE username = '$username' AND password = '$password'");
    $ketemu = mysqli_num_rows($login);
    $r =mysqli_fetch_array($login);
    
    //Apabila username dan password ditemukan maka daftarkan session
    if($ketemu > 0) {
        session_start();
        error_reporting(0);
        $_SESSION[nama] = $r['nama'];
        $_SESSION[username] = $r['username'];
        $_SESSION[password] = $r['password'];
        $_SESSION[jabatan] = $r['jabatan'];

        if($_SESSION[jabatan]==3){
            echo 
            '<script>
                window.location.href = "user/media_marketing.php?p=dashboard_marketing";
            </script>'; 
        }else if($_SESSION[jabatan]==1){
            echo 
            '<script>
                window.location.href = "user/media_akunting.php?p=dashboard_akunting";
            </script>'; 
        }else{
            echo 
            '<script>
                window.location.href = "user/media_direktur.php?p=dashboard_direktur";
            </script>'; 
        }
    }else{
        echo '
        <script>
            swal({ title: "Maaf, Login Gagal !",
            text: "Cek Kembali Username dan Password Anda..",
            type: "error"}).then(okay => {
            if (okay) {
            window.location.href = "index.html";
            }
            });
        </script>';
        echo "<br>";
        }
    }
    
    ?>
         
    </body>
</html>