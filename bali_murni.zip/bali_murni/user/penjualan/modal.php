<?php include 'fungsi/tambah.php';?>
<!--  mODAL bOX Tambah -->
<div id="tambah_penjualans" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
    <div class="modal-header" style="background-color:darkcyan;">
				<h4 class="modal-title" style="margin-left:250px; color:white;"><i class="fa fa-credit-card"></i> Tambah Penjualan</i></h4>
			</div>
			<div class="modal-body" id="modal-tambah_penjualan">
            <form action="" method="post" enctype="multipart/form-data">
          <!-- row -->
          <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Tanggal Penjualan</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="date" id="tgl" min="0" class="form-control" name="tgl" required=""
                    oninvalid="this.setCustomValidity('Tanggal Tidak Boleh Kosong !')"oninput="setCustomValidity('')">
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
          <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Pelanggan</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <select style="background-color:;" class="form-control" name="id_pelanggan">
                                  <?php 
                                  $pilih_kat="SELECT * FROM pelanggan";
                                  $proses=mysqli_query($conn, $pilih_kat);
                                  while($data_kat=mysqli_fetch_array($proses)){
                                  ?> 
                                    <option value="<?php echo $data_kat['id_pelanggan']?>" ><?php echo $data_kat['id_pelanggan'].' | '.$data_kat['nama_pelanggan']; ?></option>
                                  <?php }
                                  ?>
                      </select>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Barang</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                  <?php
                  $result = mysqli_query($conn,"SELECT * from barang");  
                    $jual = "var jual = new Array();\n";    
                    echo '<select name="id_barang" id="id_barang" class="form-control"  onchange="
                    document.getElementById(\'harga_jual\').value = jual[this.value]; 
                    "><option>--Pilih Barang--</option>';
                    while ($row = mysqli_fetch_array($result)) { 
                    echo ' <option value="'.$row['id_barang'].'">'.$row['nama_barang'].'</option>';   
                    $jual .= "jual['" . $row['id_barang'] . "'] = '" .addslashes($row ['harga_jual'] ) . "';\n";}
                    echo '</select>';
                    ?>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Harga Jual</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="number" id="harga_jual" min="0" class="form-control" name="harga_jual" required=""
                    oninvalid="this.setCustomValidity('Harga Jual Tidak Boleh Kosong !')"oninput="setCustomValidity('')" readonly>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Jumlah</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="number" id="jumlah_" min="0" class="form-control" name="jumlah" required=""
                    oninvalid="this.setCustomValidity('Jumlah tidak boleh minus / kosong !')"oninput="setCustomValidity('')">
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Total Harga</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="text" id="total_harga" class="form-control" name="total_harga" required=""
                    oninvalid="this.setCustomValidity('Jumlah tidak boleh kosong !')"oninput="setCustomValidity('')" readonly>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <!-- /.card-body -->
          <div class="card-footer">
          <button style="margin-left:400px;" name="simpan" type="submit" class="btn btn-success"></i> Simpan</button>
          <a  href="?p=penjualan" class="btn btn-warning"> Batal</a>
          </div>
        </form>
		</div>
	</div>
</div>
</div>

