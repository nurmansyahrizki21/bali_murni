<?php

function tambah($data){
    $y = date('Y');
    $m = date('m');
    $d = date('d');
    $s = date('s');
    $time = date('H:i:s');
    global $conn;
    $id_barang=$data['id_barang'];
    $tgl=$data['tgl'];
    $total_harga=$data['total_harga'];
    $jumlah=$data['jumlah'];
    $id_pelanggan=$data['id_pelanggan'];

    $id_penjualan = 'TRP'.$y.$m.$d.$s;
    $tambah = mysqli_query($conn,"INSERT INTO penjualan values('','$id_penjualan','$tgl','$id_barang','$jumlah','$total_harga','$id_pelanggan')");
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Melakukan Penjualan!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=penjualan";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah Penjualan!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=penjualan";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>