<?php
$y = date('Y');
$m = date('m');
$tgl = date('Y-m-d');
//Urut CO
function tampil_id_co(){
	global $conn;
	$query ="SELECT MAX(id)  AS 'id'
	FROM co";
	$sql=mysqli_query($conn, $query);
	$data=mysqli_fetch_array($sql);
	$x = $data['id'];
	return $x;
	};
  
  function tampil_id_co_kosong(){
	$x = 1;
	return $x;
	};

  $masukan_id_co = 0;
  if (tampil_id_co() == 0){
    $masukan_id_co = tampil_id_co_kosong();
  }else{
	  $masukan_id_co = tampil_id_co()+1;
  }
//End

$surat_jalan = 'SJ-'.$masukan_id_co.'/'.$m.'/'.$y;

 if(isset($_GET['id'])){
    $id_co=$_GET['id'];

    $ubah = mysqli_query($conn,"UPDATE co SET
                            status = 1,
                            surat_jalan = '$surat_jalan'
                            WHERE id_co = '$id_co'");

                            
    // tambah ke mutasi persediaan mengurangi stok barang
      $query = mysqli_query($conn,"SELECT * FROM detail_co WHERE id_co = '$id_co'");
      while ($row = mysqli_fetch_array($query)){
        $id_barang = $row['id_barang'];
        $jumlah    = $row['jumlah'];

        $query1 = mysqli_query($conn,"SELECT jumlah FROM barang WHERE id_barang = '$id_barang'");
            while ($row1 = mysqli_fetch_array($query1)){
                $stok_awal = $row1['jumlah'];
                $stok_akhir = $stok_awal - $jumlah;
                $update_stok_barang = mysqli_query($conn,"UPDATE barang SET jumlah = jumlah-$jumlah WHERE id_barang = '$id_barang'");
                $tambah_mutasi_persediaan = mysqli_query($conn,"INSERT INTO mutasi_persediaan values('','$tgl','$id_barang','$stok_awal','','$jumlah','$stok_akhir')");  
            }
        }
    //

    if ($ubah > 0){
        echo 
        '<script>
            swal({ title: "Status Order",
            text: "Lunas !",
            type: "success"}).then(okay => {
            if (okay) {
            window.location.href = "?p=penjualan";
                }
            });
        </script>';
        }else{
        echo '
        <script>
            swal({ title: "Gagal",
            text: "Error!",
            type: "error"}).then(okay => {
            if (okay) {
            window.location.href = "?p=penjualan";
                }
            });
        </script>';
        echo "<br>";
    }
}
       

?>