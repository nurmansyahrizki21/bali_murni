<?php
include '../config/koneksi.php';
require('../../plugins/pdf/fpdf.php');
  function rupiah($angka){
$hasil_rupiah = "Rp " . number_format($angka,0,',','.');
return $hasil_rupiah;

};
$id=$_GET['id'];
date_default_timezone_set('Asia/Jakarta');
$tahun = date('Y');
$date = date('Y-m-d');

$pdf = new FPDF("P","cm","A5");
$pdf->SetMargins(1,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','B',13);
// $pdf->Image('../../image/logo.jpg',1,1,2,2);
$pdf->SetX(1);            
$pdf->MultiCell(12.5,0.5,'PT BALI MURNI',0,'l');
$pdf->MultiCell(12.5,0.5,'CETAK SURAT JALAN',0,'l');     
$pdf->SetLineWidth(0.1);      
$pdf->Line(1,2.4,13.5,2.4);   
$pdf->SetLineWidth(0);
$pdf->ln(1);

//Tampil field pelanggan
 function tampil_pelanggan($variabel){
    global $conn;
    global $id;
    $va = $variabel;
    $query ="SELECT pelanggan.$va as 'field'
    FROM co
    INNER JOIN pelanggan
    ON co.id_pelanggan = pelanggan.id_pelanggan
    WHERE co.id_co = '$id'";
    $sql=mysqli_query($conn, $query);
    $data=mysqli_fetch_array($sql);
    $x = $data['field'];
    return $x;
  };
  $nama_pelanggan = tampil_pelanggan('nama_pelanggan');
  $alamat = tampil_pelanggan('alamat');
  $no_telp = tampil_pelanggan('no_telp');
//

//Tampil Surat Jalan
 function tampil_co($variabel){
    global $conn;
    global $id;
    $va = $variabel;
    $query ="SELECT co.$va as 'field'
    FROM co
    WHERE co.id_co = '$id'";
    $sql=mysqli_query($conn, $query);
    $data=mysqli_fetch_array($sql);
    $x = $data['field'];
    return $x;
  };
  $surat_jalan = tampil_co('surat_jalan');
//

 // sub total transaksi
 function sub_total(){
  global $conn;
  global $id;
  $query ="SELECT SUM(total_harga)  AS 'id'
  FROM detail_co WHERE id_co = '$id'";
  $sql=mysqli_query($conn, $query);
  $data=mysqli_fetch_array($sql);
  $x = $data['id'];
  return $x;
};
//

$pdf->SetFont('Arial','B',9);
$pdf->MultiCell(20.0,0.5,'Kepada Yang Terhormat : ','l');
$pdf->SetFont('Arial','',9);
$pdf->MultiCell(6,0.5, $nama_pelanggan, 'l');
$pdf->MultiCell(6,0.5, $alamat, 'l');
$pdf->MultiCell(6,0.5, $no_telp,'l');
$pdf->ln(0.5);
$pdf->SetFont('Arial','B',9);
$pdf->MultiCell(20.0,0.5,'Surat Jalan : '.$surat_jalan,'l');
$pdf->SetFont('Arial','B',7);
$pdf->MultiCell(20.0,0.5,'Tanggal : '.$date,'l');
$pdf->Cell(2, 0.8, 'Id Barang', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Nama Barang', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Tipe Barang', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Deskripsi', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Harga Jual', 1, 0, 'C');
$pdf->Cell(1, 0.8, 'Qty', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Total Harga', 1, 1, 'C');
                  
$query=mysqli_query($conn,"SELECT detail_co.* , barang.nama_barang, barang.harga_jual , barang.tipe_barang, barang.deskripsi
                            FROM detail_co
                            INNER JOIN barang
                            ON detail_co.id_barang = barang.id_barang
                            WHERE detail_co.id_co = '$id'");
                    while($data=mysqli_fetch_array($query)){
                      $pdf->SetFont('Arial','',7);
                      $pdf->Cell(2, 0.8, $data['id_barang'],1, 0, 'C');
                      $pdf->Cell(2, 0.8, 'T'.$data['nama_barang'],1, 0, 'C');
                      $pdf->Cell(2, 0.8, $data['tipe_barang'], 1, 0,'C');
                      $pdf->Cell(2, 0.8, substr($data['deskripsi'],0,5), 1, 0,'C');
                      $pdf->Cell(2, 0.8, $data['harga_jual'], 1, 0,'C');
                      $pdf->Cell(1, 0.8, $data['jumlah'], 1, 0,'C');
                      $pdf->Cell(2, 0.8, $data['total_harga'], 1, 1,'C');
                    }
                    $pdf->Cell(11, 0.8, 'Sub Total', 1, 0,'L');
                    $pdf->Cell(2, 0.8, sub_total(), 1, 1,'C');

  $pdf->ln(0.5);
$pdf->SetFont('Arial','B',7);
$pdf->MultiCell(20.0,0.3,'Keluhan mengenai barang di perkenankan paling lambat 3 hari sejak
barang diterima, selebihnya dianggap barang telah diterima dalam
kondisi baik.','l');
  $pdf->ln(1);        
	$pdf->MultiCell(26.5,0.5,'   Penerima                                                                                                                              Hormat Kami',0); 
    $pdf->ln(0.5); 
    $pdf->MultiCell(26.5,0.5,'(.......................)                                                                                                                      (.......................)',0);          	                                                                                         

	

$pdf->Output("lacoran_buku.pdf","I");
  
?>

