<!--  mODAL bOX Detail -->
<div id="detail_po" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
            <div class="modal-header" style="background-color:darkcyan;">
                    <h4 class="modal-title" style="margin-left:250px; color:white;"><i class="fa fa-file"></i> Detail Purchase Order</i></h4>
            </div>
            <div class="modal-body" id="data_detail_po">
          
            </div>
	    </div>
    </div>
</div>

