<?php 
include '../config/koneksi.php';
if($_POST['id']){
    $id = $_POST['id'];
    $tgl = $_POST['tgl'];
    
    // sub total transaksi
    function sub_total(){
        global $conn;
        global $id;
        $query ="SELECT SUM(total_harga)  AS 'id'
        FROM detail_po WHERE id_po = '$id'";
        $sql=mysqli_query($conn, $query);
        $data=mysqli_fetch_array($sql);
        $x = $data['id'];
        return $x;
    };
    //
?>
        <form action="" method="post">
            <table cellspacing="1" cellpadding="5">
                <tr>
                    <th>Invoice</th>
                    <td>:</td>
                    <td><?php echo $id; ?></td>
                </tr>
                    <th>Tgl</th>
                    <td>:</td>
                    <td><?php echo $tgl; ?></td>
                <tr>
                <tr>
                    <th>Supplier</th>
                    <td>:</td>
                    <td><?php echo 'Hansgrohe'; ?></td>
                </tr>
                   
                </tr>
            </table>
            <div class="table-responsive">
            <table class="table table-striped table-bordered first" id="cari">
                <thead>
                    <tr>
                        <th>Id Barang</th>
                        <th>Nama Barang</th>
                        <th>Tipe Barang</th>
                        <th>Deskripsi</th>
                        <th>Harga Jual Barang</th>
                        <th>Jumlah Order</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $no=1;
                    $query="SELECT detail_po.* ,barang.nama_barang, barang.harga_beli , barang.tipe_barang, barang.deskripsi
                    FROM detail_po
                    INNER JOIN barang
                    ON detail_po.id_barang = barang.id_barang
                    WHERE detail_po.id_po = '$id'";
                    $sql=mysqli_query($conn, $query);
                    while ($data=mysqli_fetch_array($sql)) {
                    ?>
                <tr>
                    <td><?php echo $data['id_barang'];?></td>
                    <td><?php echo $data['nama_barang'];?></td>
                    <td><?php echo $data['tipe_barang'];?></td>
                    <td><?php echo $data['deskripsi']?></td>
                    <td><?php echo $data['harga_beli'];?></td>
                    <td><?php echo $data['jumlah'];?></td>
                    <td><?php echo $data['total_harga'];?></td>
                    <?php  $no++; } ?>
                </tbody>
                <tfoot>
                    <th colspan="6">Sub Total :</th>
                    <th><?php echo sub_total();?></th>
                </tfoot>
            </table>
            </div>
        </form>
<?php }?>