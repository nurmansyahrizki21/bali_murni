<?php
function tambah($data){
    $y = date('Y');
    $m = date('m');
    $d = date('d');
    $s = date('s');
    $time = date('H:i:s');
    global $conn;
    $id_po=$data['id_po'];
    $tgl=$data['tgl'];
    
    $tambah = mysqli_query($conn,"INSERT INTO po values('','$id_po','$tgl','0')");
    $tambah2 = mysqli_query($conn,"INSERT INTO detail_po SELECT * FROM detail_po_tmp");
    $delete  = mysqli_query($conn,"DELETE FROM detail_po_tmp");

      // tambah ke mutasi persediaan menambah stok barang
      $query = mysqli_query($conn,"SELECT * FROM detail_po WHERE id_po = '$id_po'");
      while ($row = mysqli_fetch_array($query)){
        $id_barang = $row['id_barang'];
        $jumlah    = $row['jumlah'];

        $query1 = mysqli_query($conn,"SELECT jumlah FROM barang WHERE id_barang = '$id_barang'");
            while ($row1 = mysqli_fetch_array($query1)){
                $stok_awal = $row1['jumlah'];
                $stok_akhir = $stok_awal + $jumlah;
                $update_stok_barang = mysqli_query($conn,"UPDATE barang SET jumlah = jumlah+$jumlah WHERE id_barang = '$id_barang'");
                $tambah_mutasi_persediaan = mysqli_query($conn,"INSERT INTO mutasi_persediaan values('','$tgl','$id_barang','$stok_awal','$jumlah','','$stok_akhir')");  
            }
        }
    //
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Menambah Purchase Order!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=po";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah Purchase Order!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=po";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>