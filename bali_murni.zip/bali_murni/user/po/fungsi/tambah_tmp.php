<?php 
 include '../../config/koneksi.php';
 $id_barang=$_POST['id_barang'];
 $total_harga=$_POST['total_harga'];
 $jumlah=$_POST['jumlah'];
 $id_po=$_POST['id_po'];
 
 if($total_harga==true){
    $tambah = mysqli_query($conn,"INSERT INTO detail_po_tmp values('','$id_po','$id_barang','$jumlah','$total_harga')");
 }
?>