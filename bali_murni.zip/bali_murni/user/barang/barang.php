<?php include 'fungsi.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h4><i class="fa fa-briefcase"></i> Data Barang</h4>
            <div class="card">
                <div class="card-header">
                <a href="?p=tambah_barang" class="btn btn-primary"><i class="fa fa-plus"></i>  Tambah</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first" id="cari">
                            <thead>
                                <tr>
                                    <th>Id Barang</th>
                                    <th>Tgl</th>
                                    <th>Nama Barang</th>
                                    <th>Tipe Barang</th>
                                    <th>Deskripsi</th>
                                    <th>Harga Beli</th>
                                    <th>Harga Jual</th>
                                    <th>Jumlah</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no=1;
                                $query="SELECT * FROM barang";
                                $sql=mysqli_query($conn, $query);
                                while ($data=mysqli_fetch_array($sql)) {
                                ?>
                            <tr>
                                <td><?php echo $data['id_barang'];?></td>
                                <td><?php echo $data['tgl'];?></td>
                                <td><?php echo $data['nama_barang'];?></td>
                                <td><?php echo $data['tipe_barang'];?></td>
                                <td><?php echo $data['deskripsi']?></td>
                                <td><?php echo $data['harga_beli'];?></td>
                                <td><?php echo $data['harga_jual'];?></td>
                                <td><?php echo $data['jumlah'];?></td>
                                <td>  
                                <a href="?p=ubah_barang&id=<?php echo $data['id'];?>" class="btn btn-primary btn-sm" style="margin-bottom: 2px;"><i class="fa fa-edit"></i> Ubah</a> 
                            </td>
                            </tr>  
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'modal.php';?>