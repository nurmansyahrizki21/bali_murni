<?php

function tambah($data){
    global $conn;
    $id_barang=$data['id_barang'];
    $tgl=$data['tgl'];
    $nama_barang=$data['nama_barang'];
    $tipe_barang=$data['tipe_barang'];
    $deskripsi=$data['deskripsi'];
    $harga_beli=$data['harga_beli'];
    $harga_jual=$data['harga_jual'];
    $tambah = mysqli_query($conn,"INSERT INTO barang values('','$id_barang','$tgl','$nama_barang','$tipe_barang','$deskripsi','$harga_beli','$harga_jual','0')");
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Menambah Barang!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=barang";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah Barang!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=barang";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>