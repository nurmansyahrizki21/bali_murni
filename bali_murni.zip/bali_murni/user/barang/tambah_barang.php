<?php include 'fungsi/tambah.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="card-header">
                <h5><i class="fa fa-briefcase"> Tambah Data Barang</i></h5>
                </div>
                <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data" style="margin-left:80px;">
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Id Barang</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="id_barang" id="inputPassword3" required=""
                            oninvalid="this.setCustomValidity('Id Barang Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Tgl</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl" id="inputPassword3" required=""
                        oninvalid="this.setCustomValidity('Tgl Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Nama Barang</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nama_barang" id="inputPassword3" required=""
                            oninvalid="this.setCustomValidity('Nama Barang  Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Tipe Barang</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="tipe_barang" id="inputPassword3" required=""
                         oninvalid="this.setCustomValidity('Tipe Barang Tidak Boleh Kosong !')"oninput="setCustomValidity('')" > 
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Deskripsi</label>
                        <div class="col-sm-8">
                           <textarea name="deskripsi" class="form-control" id="" cols="30" rows="2" required=""
                        oninvalid="this.setCustomValidity('Deskripsi Tidak Boleh Kosong !')"oninput="setCustomValidity('')" ></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Harga Beli</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="harga_beli" id="inputPassword3" required=""
                    oninvalid="this.setCustomValidity('Harga beli Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Harga Jual</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="harga_jual" id="inputPassword3" required=""
                    oninvalid="this.setCustomValidity('Harga Jual Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <div class="col-sm-12">
                                <a href="?p=barang" class="btn btn-danger float-right ">BATAL</a>
                            </div>
                            <div class="col-sm-11">
                                <button type="submit" name="simpan" class="btn btn-primary float-right mr-2">SIMPAN</button>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>