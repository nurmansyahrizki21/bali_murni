<?php 
include 'config/koneksi.php';

//Jumlah Gambar
// function jumlah_gambar(){
// 	global $conn;
// 	$query ="SELECT COUNT(id_gallery) AS 'Jumlah' FROM gallery";
// 	$sql=mysqli_query($conn, $query);
// 	$data=mysqli_fetch_array($sql);
// 	$x = $data['Jumlah'];
// 	return $x;
// 	};
// 	$jumlah_gambar = jumlah_gambar();
//

?>

<div class="card-home container-fluid">
    <div class="card-row row">
        <div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
            <div class="card border-3 border-top border-top-primary">
                <div class="card-body">
                    <h3 class="text-muted">WELCOME</h3>
                    <div class="metric-value d-inline-block">
                        <img class="" src="../logo/logo.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>