<?php 
$conn = mysqli_connect("localhost","root","","bali_murni");
?>