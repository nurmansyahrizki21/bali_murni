<?php
include '../config/koneksi.php';
require('../../plugins/pdf/fpdf.php');
  function rupiah($angka){
  
        $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
        return $hasil_rupiah;
       
      };

$tgl1=$_GET['tanggal_awal'];
$tgl2=$_GET['tanggal_akhir'];
date_default_timezone_set('Asia/Jakarta');
$tahun = date('Y');

$pdf = new FPDF("L","cm","A4");
$pdf->SetMargins(1,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','B',18);
// $pdf->Image('../../image/logo.png',1,1,2,2);
$pdf->SetX(4);            
$pdf->MultiCell(21.5,0.5,'Hansgrohe',0,'C');
$pdf->SetX(4);
$pdf->SetFont('Arial','B',10);
$pdf->MultiCell(21.5,0.5,'Telpon : 0898-5429-324',0,'C');    
$pdf->SetFont('Arial','B',10);
$pdf->SetX(4);
$pdf->MultiCell(21.5,0.5,'Bali - Indonesia',0,'C');
$pdf->SetX(4);
$pdf->Line(1,3.1,28.5,3.1);
$pdf->SetLineWidth(0.1);      
$pdf->Line(1,3.2,28.5,3.2);   
$pdf->SetLineWidth(0);
$pdf->ln(1);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(5,0.7,"Di cetak pada : ".date("D-d/m/Y"),0,0,'C');
$pdf->ln(1);
$pdf->SetFont('Arial','B',15);
$pdf->MultiCell(27.5,0.5,'Laporan Penjualan',0,'C');
$pdf->SetFont('Arial','',11);
$pdf->MultiCell(20.5,0.5,'Tanggal            : '.$tgl1.' - '.$tgl2,0,'l');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Invoice', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Tanggal', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Pelanggan', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Id Barang', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Nama Barang', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Tipe Barang', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Deskripsi', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Harga', 1, 0, 'C');
$pdf->Cell(2, 0.8, 'Jmlh Order', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Total Harga', 1, 1, 'C');


    $no=1;
    $query=mysqli_query($conn, "SELECT pelanggan.nama_pelanggan, detail_co.*, co.* , barang.nama_barang, barang.harga_jual , barang.tipe_barang, barang.deskripsi
    FROM co
    INNER JOIN detail_co
    ON co.id_co = detail_co.id_co
    INNER JOIN barang
    ON detail_co.id_barang = barang.id_barang
    INNER JOIN pelanggan
    ON pelanggan.id_pelanggan = co.id_pelanggan
    WHERE co.tgl >= '$tgl1' and co.tgl <= '$tgl2'");
	while($lihat=mysqli_fetch_array($query)){
        $pdf->SetFont('Arial','',7);
        
            $pdf->Cell(1, 0.8, $no , 1, 0, 'C');
            $pdf->Cell(3, 0.8, $lihat['id_co'],1, 0, 'C');
            $pdf->Cell(2, 0.8, $lihat['tgl'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['nama_pelanggan'], 1, 0,'C');
            $pdf->Cell(2, 0.8, $lihat['id_barang'], 1, 0,'C');
            $pdf->Cell(3, 0.8, $lihat['nama_barang'], 1, 0,'C');
            $pdf->Cell(3, 0.8, $lihat['tipe_barang'], 1, 0,'C');
            $pdf->Cell(3, 0.8, substr($lihat['deskripsi'],0,13), 1, 0,'C');
            $pdf->Cell(2, 0.8, $lihat['harga_jual'], 1, 0,'C');
            $pdf->Cell(2, 0.8, $lihat['jumlah'], 1, 0,'C');
            $pdf->Cell(3, 0.8, rupiah($lihat['total_harga']), 1, 1,'C');
            $no++;
    }
 

$pdf->Output();
?>
