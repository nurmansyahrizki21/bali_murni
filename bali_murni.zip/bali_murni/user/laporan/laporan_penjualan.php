<?php
$now = date('Y-m-d');
$dates = date('Y-m-d');
    $tgl1 = $now;
    $tgl2 = $now;
    if(isset($_POST['cek'])){
        $tgl1 = $_POST['tgl1'];
        $tgl2 = $_POST['tgl2'];
    }
?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h4><i class="fa fa-book"></i> Laporan Penjualan</h4>
            <div class="card">
                <div class="card-header">
                <form action="" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Tanggal Awal</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
                            </div>
                            <input VALUE="<?php echo $tgl1?>" type="date" name="tgl1" id="tgl2" class="form-control"  required=""
                                                                oninvalid="this.setCustomValidity('Tanggal Awal tidak boleh kosong !')"oninput="setCustomValidity('')">
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tanggal Akhir</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
                                </div>
                                <input type="date" VALUE="<?php echo $tgl2?>" id="tgl2" name="tgl2" class="form-control"  required=""
                                                                    oninvalid="this.setCustomValidity('Tanggal Akhir tidak boleh kosong !')"oninput="setCustomValidity('')">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <div class="input-group">
                                <button type="submit" name="cek" class="btn btn-primary"><i class="fa fa-search"></i> Preview </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2" style="margin-left:-50px;">
                        <div class="form-group">
                            <div class="input-group">
                            <h2><a href="../user/laporan/cetak_laporan_penjualan.php?tanggal_awal=<?php echo $tgl1 ?>&tanggal_akhir=<?php echo $tgl2 ?>" target="_blank" style="background-color:darkcyan;" class="btn btn-success"><i class="fa fa-print"></i> Cetak Laporan</a></h2> 
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                </form>
               
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first" id="cari">
                            <thead>
                                <tr>
                                    <th>Id Penjualan</th>
                                    <th>Tgl</th>
                                    <th>Pelanggan</th>
                                    <th>Id Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Tipe Barang</th>
                                    <th>Deskripsi</th>
                                    <th>Harga Barang</th>
                                    <th>Jumlah Penjualan</th>
                                    <th>Total Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no=1;
                                $query="SELECT pelanggan.nama_pelanggan, detail_co.*, co.* , barang.nama_barang, barang.harga_jual , barang.tipe_barang, barang.deskripsi
                                FROM co
                                INNER JOIN detail_co
                                ON co.id_co = detail_co.id_co
                                INNER JOIN barang
                                ON detail_co.id_barang = barang.id_barang
                                INNER JOIN pelanggan
                                ON pelanggan.id_pelanggan = co.id_pelanggan
                                WHERE co.tgl >= '$tgl1' and co.tgl <= '$tgl2'";
                                $sql=mysqli_query($conn, $query);
                                while ($data=mysqli_fetch_array($sql)) {
                                ?>
                            <tr>
                                <td><?php echo $data['id_co'];?></td>
                                <td><?php echo $data['tgl'];?></td>
                                <td><?php echo $data['nama_pelanggan'];?></td>
                                <td><?php echo $data['id_barang'];?></td>
                                <td><?php echo $data['nama_barang'];?></td>
                                <td><?php echo $data['tipe_barang'];?></td>
                                <td><?php echo $data['deskripsi']?></td>
                                <td><?php echo $data['harga_jual'];?></td>
                                <td><?php echo $data['jumlah'];?></td>
                                <td><?php echo $data['total_harga'];?></td>
                            </tr>  
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'modal.php';?>