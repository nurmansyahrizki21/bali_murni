<?php
include '../config/koneksi.php';
require('../../plugins/pdf/fpdf.php');
  function rupiah($angka){
  
        $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
        return $hasil_rupiah;
       
      };

$tgl1=$_GET['tanggal_awal'];
$tgl2=$_GET['tanggal_akhir'];
date_default_timezone_set('Asia/Jakarta');
$tahun = date('Y');

$pdf = new FPDF("L","cm","A4");
$pdf->SetMargins(1,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','B',18);
// $pdf->Image('../../image/logo.png',1,1,2,2);
$pdf->SetX(4);            
$pdf->MultiCell(21.5,0.5,'Hansgrohe',0,'C');
$pdf->SetX(4);
$pdf->SetFont('Arial','B',10);
$pdf->MultiCell(21.5,0.5,'Telpon : 0898-5429-324',0,'C');    
$pdf->SetFont('Arial','B',10);
$pdf->SetX(4);
$pdf->MultiCell(21.5,0.5,'Bali - Indonesia',0,'C');
$pdf->SetX(4);
$pdf->Line(1,3.1,28.5,3.1);
$pdf->SetLineWidth(0.1);      
$pdf->Line(1,3.2,28.5,3.2);   
$pdf->SetLineWidth(0);
$pdf->ln(1);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(5,0.7,"Di cetak pada : ".date("D-d/m/Y"),0,0,'C');
$pdf->ln(1);
$pdf->SetFont('Arial','B',15);
$pdf->MultiCell(27.5,0.5,'Laporan Persediaan Barang',0,'C');
$pdf->SetFont('Arial','',11);
$pdf->MultiCell(20.5,0.5,'Tanggal            : '.$tgl1.' - '.$tgl2,0,'l');
$pdf->SetFont('Arial','B',9);
$pdf->Cell(2, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Tanggal', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Id Barang', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Nama Barang', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Stok Awal', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Masuk', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Keluar', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Stok Akhir', 1, 1, 'C');


    $no=1;
    $query=mysqli_query($conn, "SELECT mutasi_persediaan.*, barang.* 
    FROM mutasi_persediaan
    INNER JOIN barang 
    ON mutasi_persediaan.`id_barang` = barang.`id_barang`
    where mutasi_persediaan.tgl >= '$tgl1' and mutasi_persediaan.tgl <= '$tgl2'");
	while($lihat=mysqli_fetch_array($query)){
        $pdf->SetFont('Arial','',10);
        
            $pdf->Cell(2, 0.8, $no , 1, 0, 'C');
            $pdf->Cell(3, 0.8, $lihat['tgl'], 1, 0,'C');
            $pdf->Cell(3, 0.8, $lihat['id_barang'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['nama_barang'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['stok_awal'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['masuk'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['keluar'], 1, 0,'C');
            $pdf->Cell(4, 0.8, $lihat['stok_akhir'], 1, 1,'C');
            $no++;
    }
 

$pdf->Output();
?>
