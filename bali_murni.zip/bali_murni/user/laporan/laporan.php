<?php include 'fungsi.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <form style="background-color:white;" height="200px;">
            <div class="table-responsive pt-2 pl-2 pr-2 pb-2">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 align="center"><i style="color:darkcyan" class="fa fa-book fa-5x"></i></h5>
                                <h5 align="center"><a href="?p=laporan_pembelian" style="background-color:whitesmoke; color:black; border:3px solid darkcyan" class="btn btn-success">Laporan Purchase Order</a></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 align="center"><i style="color:darkcyan" tyle="color:darkcyan"class="fa fa-book fa-5x"></i></h5>
                                <h5 align="center"><a href="?p=laporan_penjualan" style="background-color:whitesmoke; color:black; border:3px solid darkcyan" class="btn btn-success">Laporan Penjualan</a></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 align="center"><i style="color:darkcyan" class="fa fa-book fa-5x"></i></h5>
                                <h5 align="center"><a href="?p=laporan_persediaan_barang" style="background-color:whitesmoke; color:black; border:3px solid darkcyan" class="btn btn-success">Laporan Persediaan Barang</a></h5>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php include 'modal.php';?>