<?php
$now = date('Y-m-d');
$dates = date('Y-m-d');
    $tgl1 = $now;
    $tgl2 = $now;
    if(isset($_POST['cek'])){
        $tgl1 = $_POST['tgl1'];
        $tgl2 = $_POST['tgl2'];
    }
?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h4><i class="fa fa-book"></i> Laporan Penrsediaan Barang</h4>
            <div class="card">
                <div class="card-header">
                <form action="" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Tanggal Awal</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
                            </div>
                            <input VALUE="<?php echo $tgl1?>" type="date" name="tgl1" id="tgl2" class="form-control"  required=""
                                                                oninvalid="this.setCustomValidity('Tanggal Awal tidak boleh kosong !')"oninput="setCustomValidity('')">
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tanggal Akhir</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
                                </div>
                                <input type="date" VALUE="<?php echo $tgl2?>" id="tgl2" name="tgl2" class="form-control"  required=""
                                                                    oninvalid="this.setCustomValidity('Tanggal Akhir tidak boleh kosong !')"oninput="setCustomValidity('')">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <div class="input-group">
                                <button type="submit" name="cek" class="btn btn-primary btn-sm"><i class="fa fa-search"></i> Preview </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2" style="margin-left:-50px;">
                        <div class="form-group">
                            <div class="input-group">
                            <h2><a href="../user/laporan/cetak_laporan_persediaan.php?tanggal_awal=<?php echo $tgl1 ?>&tanggal_akhir=<?php echo $tgl2 ?>" target="_blank" style="background-color:darkcyan;" class="btn btn-success btn-sm"><i class="fa fa-print"></i> Cetak Laporan</a></h2> 
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                </form>
               
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table table-striped table-bordered first" id="cari">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tgl</th>
                                    <th>Id Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Stok Awal</th>
                                    <th>Masuk</th>
                                    <th>Keluar</th>
                                    <th>Stok Akhir</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no=1;
                                $query="SELECT mutasi_persediaan.*, barang.* 
                                FROM mutasi_persediaan
                                INNER JOIN barang 
                                ON mutasi_persediaan.`id_barang` = barang.`id_barang`
                                where mutasi_persediaan.tgl >= '$tgl1' and mutasi_persediaan.tgl <= '$tgl2'";
                                $sql=mysqli_query($conn, $query);
                                while ($data=mysqli_fetch_array($sql)) {
                                ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo $data['tgl'];?></td>
                                <td><?php echo $data['id_barang'];?></td>
                                <td><?php echo $data['nama_barang'];?></td>
                                <td><?php echo $data['stok_awal'];?></td>
                                <td><?php echo $data['masuk']?></td>
                                <td><?php echo $data['keluar'];?></td>
                                <td><?php echo $data['stok_akhir'];?></td>
                            </tr>  
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'modal.php';?>