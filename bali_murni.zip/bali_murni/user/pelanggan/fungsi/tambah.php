<?php

function tambah($data){
    global $conn;
    $id_pelanggan=$data['id_pelanggan'];
    $nama_pelanggan=$data['nama_pelanggan'];
    $alamat=$data['alamat'];
    $no_telp=$data['no_telp'];
    $email=$data['email'];
    $tambah = mysqli_query($conn,"INSERT INTO pelanggan values('','$id_pelanggan','$nama_pelanggan','$alamat','$no_telp','$email')");
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Menambah Pelanggan!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=pelanggan";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah Pelanggan!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=pelanggan";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>