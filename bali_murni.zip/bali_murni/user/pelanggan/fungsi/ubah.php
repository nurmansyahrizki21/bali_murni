<?php

 if(isset($_GET['id'])){
    $id=$_GET['id'];

    function getData($query){
        global $conn;
        $sql = mysqli_query($conn,$query);
        $getData = mysqli_fetch_array($sql);
        return $getData;
    }

    $getDataId = getData("SELECT * from pelanggan WHERE id ='$id'");
    
    function seeData($key){
        global $getDataId;
        $see = $getDataId[$key];
        return $see;
    } 
    
    }else{
        function seeData($key){
        $see = '';
    } 
  }

  function ubah($data){
    global $conn;
    $id=$data['id'];
    $id_pelanggan=$data['id_pelanggan'];
    $nama_pelanggan=$data['nama_pelanggan'];
    $alamat=$data['alamat'];
    $no_telp=$data['no_telp'];
    $email=$data['email'];

    $ubah = mysqli_query($conn,"UPDATE pelanggan SET
                            id_pelanggan = '$id_pelanggan',
                            nama_pelanggan = '$nama_pelanggan',
                            alamat = '$alamat',
                            no_telp = '$no_telp',
                            email = '$email'
                            WHERE id = '$id'");
    return $ubah;
}

  
if(isset($_POST['ubah'])){
    if (ubah($_POST) > 0){
        echo 
        '<script>
            swal({ title: "Berhasil",
            text: "Mengubah Pelanggan!",
            type: "success"}).then(okay => {
            if (okay) {
            window.location.href = "?p=pelanggan";
                }
            });
        </script>';
        }else{
        echo '
        <script>
            swal({ title: "Gagal",
            text: "Mengubah Pelanggan!",
            type: "error"}).then(okay => {
            if (okay) {
            window.location.href = "?p=pelanggan";
                }
            });
        </script>';
        echo "<br>";
        }
    }       

?>