<?php include 'fungsi/ubah.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="card-header">
                <h5><i class="fa fa-building"> Ubah Data Pelanggan</i></h5>
                </div>
                <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data" style="margin-left:80px;">
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Id Pelanggan</label>
                        <div class="col-sm-8">
                            <input type="hidden" name="id" value="<?php echo seeData('id'); ?>">
                            <input type="text" class="form-control" name="id_pelanggan" id="inputPassword3" value="<?php echo seeData('id_pelanggan'); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Nama Pelanggan</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nama_pelanggan" id="inputPassword3" value="<?php echo seeData('nama_pelanggan'); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Alamat</label>
                        <div class="col-sm-8">
                           <textarea name="alamat" class="form-control" id="" cols="30" rows="2"><?php echo seeData('alamat'); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">No Telp</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="no_telp" id="inputPassword3" value="<?php echo seeData('no_telp'); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="email" id="inputPassword3" value="<?php echo seeData('email'); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <div class="col-sm-12">
                                <a href="?p=pelanggan" class="btn btn-danger float-right ">BATAL</a>
                            </div>
                            <div class="col-sm-11">
                                <button type="submit" name="ubah" class="btn btn-primary float-right mr-2">SIMPAN</button>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>