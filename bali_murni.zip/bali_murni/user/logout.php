<html>
<head>
  <!-- Sweat Alert -->
  <script src="../plugins/sweetalert/sweetalert.all.min.js"></script>
  <link rel='stylesheet' href='../plugins/sweetalert/sweetalert.min.css'>
</head>
<body>
    <?php
    session_start();
    session_destroy();
    echo 
    '<script>
        window.location.href = "../index.html";
    </script>';
    ?>
</body>
</html>