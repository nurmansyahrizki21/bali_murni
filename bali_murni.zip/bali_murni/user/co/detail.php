<!--  mODAL bOX Detail -->
<div id="details" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
            <div class="modal-header" style="background-color:darkcyan;">
                    <h4 class="modal-title" style="margin-left:250px; color:white;"><i class="fa fa-file"></i> Detail Confirmation Order</i></h4>
            </div>
            <div class="modal-body" id="data_detail">
            </div>
	    </div>
    </div>
</div>

