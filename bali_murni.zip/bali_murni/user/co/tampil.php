<?php include '../config/koneksi.php';
include 'fungsi/tambah.php';

$now = date('Y-m-d');
$y = date('Y');
$m = date('m');
$d = date('d');
$s = date('s');
//Urut INV
function tampil_id_co(){
	global $conn;
	$query ="SELECT MAX(id)  AS 'id'
	FROM co";
	$sql=mysqli_query($conn, $query);
	$data=mysqli_fetch_array($sql);
	$x = $data['id'];
	return $x;
	};
  
  function tampil_id_co_kosong(){
	$x = 1;
	return $x;
	};

  $masukan_id_co = 0;
  if (tampil_id_co() == 0){
    $masukan_id_co = tampil_id_co_kosong();
  }else{
	  $masukan_id_co = tampil_id_co()+1;
  }
//End

$id_co = 'INV'.$y.$m.$d.$masukan_id_co;

?>

    <div class="table-responsive">
        <table class="table table-striped table-bordered first" id="cari">
            <thead>
                <tr>
                    <th>Id Barang</th>
                    <th>Nama Barang</th>
                    <th>Tipe Barang</th>
                    <th>Deskripsi</th>
                    <th>Harga Jual Barang</th>
                    <th>Jumlah Order</th>
                    <th>Total Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $no=1;
                $query="SELECT detail_co_tmp.* ,barang.nama_barang, barang.harga_jual , barang.tipe_barang, barang.deskripsi
                FROM detail_co_tmp
                INNER JOIN barang
                ON detail_co_tmp.id_barang = barang.id_barang";
                $sql=mysqli_query($conn, $query);
                while ($data=mysqli_fetch_array($sql)) {
                ?>
            <tr>
                <td><?php echo $data['id_barang'];?></td>
                <td><?php echo $data['nama_barang'];?></td>
                <td><?php echo $data['tipe_barang'];?></td>
                <td><?php echo $data['deskripsi']?></td>
                <td><?php echo $data['harga_jual'];?></td>
                <td><?php echo $data['jumlah'];?></td>
                <td><?php echo $data['total_harga'];?></td>
                <td><button id="<?php echo $data['id']; ?>" class="btn btn-danger btn-sm hapus_data"> <i class="fa fa-times"></i> Batal </button></td>
            </tr>  
                <?php  $no++; } ?>
            </tbody>
        </table>
        <div class="card-footer">
        <form action="" method="post">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <input type="hidden" name="id_co" value="<?php echo $id_co; ?>">
                        <input type="date" id="tgl" min="0" class="form-control" name="tgl" value="<?php echo $now ?>" required=""
                        oninvalid="this.setCustomValidity('Tanggal Tidak Boleh Kosong !')"oninput="setCustomValidity('')">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <select style="background-color:;" class="form-control" name="id_pelanggan">
                                    <?php 
                                    $pilih_kat="SELECT * FROM pelanggan";
                                    $proses=mysqli_query($conn, $pilih_kat);
                                    while($data_kat=mysqli_fetch_array($proses)){
                                    ?> 
                                        <option value="<?php echo $data_kat['id_pelanggan']?>" ><?php echo $data_kat['id_pelanggan'].' | '.$data_kat['nama_pelanggan']; ?></option>
                                    <?php }
                                    ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <button name="simpan" type="submit" class="btn btn-primary"></i> Simpan</button>
                    </div>
                </div>
            </div>
        </div>
        </form>
        </div>

       <!-- Delete data Tanpa Reload , CO -->
        <script type="text/javascript">
            $(document).ready(function(){
                $("#hapus").click(function(){
                    var data = $('#form_hapus').serialize();
                    $.ajax({
                        type	: 'POST',
                        url	: "co/fungsi/hapus_tmp.php",
                        data: data,

                        cache	: false,
                        success	: function(data){
                            $('#tampil').load("co/tampil.php");
                        }
                    });
                });
            });
        </script>

        <script type="text/javascript">           
        $(document).on('click', '.hapus_data', function(){
            var id = $(this).attr('id');
            $.ajax({
                type: 'POST',
                url: "co/fungsi/hapus_tmp.php",
                data: {id:id},
                success: function() {
                    $('#tampil').load("co/tampil.php");
                }
            });
        });
        </script>
