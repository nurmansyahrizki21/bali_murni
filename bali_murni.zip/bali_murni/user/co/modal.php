<?php 
include 'fungsi/tambah.php';
$now = date('Y-m-d');
$y = date('Y');
$m = date('m');
$d = date('d');
$s = date('s');
//Urut CO
function tampil_id_co(){
	global $conn;
	$query ="SELECT MAX(id)  AS 'id'
	FROM co";
	$sql=mysqli_query($conn, $query);
	$data=mysqli_fetch_array($sql);
	$x = $data['id'];
	return $x;
	};
  
  function tampil_id_co_kosong(){
	$x = 1;
	return $x;
	};

  $masukan_id_co = 0;
  if (tampil_id_co() == 0){
    $masukan_id_co = tampil_id_co_kosong();
  }else{
	  $masukan_id_co = tampil_id_co()+1;
  }
//End

$id_co = 'INV'.$y.$m.$d.$masukan_id_co;

?>
<!--  mODAL bOX Tambah -->
<div id="tambah_pembelians" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
    <div class="modal-header" style="background-color:darkcyan;">
				<h4 class="modal-title" style="margin-left:230px; color:white;"><i class="fa fa-file"></i> Tambah Confirmation Order</i></h4>
			</div>
			<div class="modal-body" id="modal-tambah_pembelian">
            <form id="form" method="post" enctype="multipart/form-data">
          <!-- row -->
          <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Invoice</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="text" id="text" value="<?php echo $id_co; ?>" min="0" class="form-control" name="id_co" required="" 
                    oninvalid="this.setCustomValidity('Tanggal Tidak Boleh Kosong !')"oninput="setCustomValidity('')" readonly>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Barang</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                  <?php
                  $result = mysqli_query($conn,"SELECT * from barang");  
                    $jual = "var jual = new Array();\n";    
                    echo '<select name="id_barang" id="id_barang" class="form-control"  onchange="
                    document.getElementById(\'harga_jual\').value = jual[this.value]; 
                    "><option>--Pilih Barang--</option>';
                    while ($row = mysqli_fetch_array($result)) { 
                    echo ' <option value="'.$row['id_barang'].'">'.$row['nama_barang'].'</option>';   
                    $jual .= "jual['" . $row['id_barang'] . "'] = '" .addslashes($row ['harga_jual'] ) . "';\n";}
                    echo '</select>';
                    ?>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Harga Jual</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="number" id="harga_jual" min="0" class="form-control" name="harga_jual" required=""
                    oninvalid="this.setCustomValidity('Harga jual Tidak Boleh Kosong !')"oninput="setCustomValidity('')" readonly>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Jumlah</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="number" id="jumlah_jual" min="0" class="form-control" name="jumlah" required=""
                    oninvalid="this.setCustomValidity('Jumlah tidak boleh minus / kosong !')"oninput="setCustomValidity('')">
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  <label for="">Total Harga</label>
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <input type="text" id="total_harga_jual" class="form-control" name="total_harga" required=""
                    oninvalid="this.setCustomValidity('Total harga tidak boleh kosong !')"oninput="setCustomValidity('')" readonly>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                  <div class="input-group">
                  </div>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="input-group">
                    <button id="Submit" name="submit" type="button" class="btn btn-primary"></i> Tambah</button>
                  </div>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <!-- /.card-body -->
        </form>
        <div id="tampil">
        
        </div>
		</div>
	</div>
</div>
</div>

