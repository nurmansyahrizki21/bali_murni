<?php

 if(isset($_GET['id'])){
    $id=$_GET['id'];

    function getData($query){
        global $conn;
        $sql = mysqli_query($conn,$query);
        $getData = mysqli_fetch_array($sql);
        return $getData;
    }

    $getDataId = getData("SELECT * from barang WHERE id ='$id'");
    
    function seeData($key){
        global $getDataId;
        $see = $getDataId[$key];
        return $see;
    } 
    
    }else{
        function seeData($key){
        $see = '';
    } 
  }

  function ubah($data){
    global $conn;
    $id=$data['id'];
    $id_barang=$data['id_barang'];
    $tgl=$data['tgl'];
    $nama_barang=$data['nama_barang'];
    $tipe_barang=$data['tipe_barang'];
    $deskripsi=$data['deskripsi'];
    $harga_barang=$data['harga_barang'];
    $jumlah=$data['jumlah'];

    $ubah = mysqli_query($conn,"UPDATE barang SET
                            id_barang = '$id_barang',
                            nama_barang = '$nama_barang',
                            tgl = '$tgl',
                            tipe_barang = '$tipe_barang',
                            deskripsi = '$deskripsi',
                            harga_barang = '$harga_barang',
                            jumlah = '$jumlah'
                            WHERE id = '$id'");
    return $ubah;
}

  
if(isset($_POST['ubah'])){
    if (ubah($_POST) > 0){
        echo 
        '<script>
            swal({ title: "Berhasil",
            text: "Mengubah Barang!",
            type: "success"}).then(okay => {
            if (okay) {
            window.location.href = "?p=barang";
                }
            });
        </script>';
        }else{
        echo '
        <script>
            swal({ title: "Gagal",
            text: "Mengubah Barang!",
            type: "error"}).then(okay => {
            if (okay) {
            window.location.href = "?p=barang";
                }
            });
        </script>';
        echo "<br>";
        }
    }       

?>