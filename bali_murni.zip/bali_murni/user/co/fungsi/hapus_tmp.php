<?php 
 include '../../config/koneksi.php';
 $id=$_POST['id'];;
 $delete = mysqli_query($conn,"DELETE FROM detail_co_tmp where id = $id");

?>