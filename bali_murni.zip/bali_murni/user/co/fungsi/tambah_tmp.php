<?php 
 include '../../config/koneksi.php';
 $id_barang=$_POST['id_barang'];
 $total_harga=$_POST['total_harga'];
 $jumlah=$_POST['jumlah'];
 $id_co=$_POST['id_co'];
 
 if($total_harga==true){
    $tambah = mysqli_query($conn,"INSERT INTO detail_co_tmp values('','$id_co','$id_barang','$jumlah','$total_harga')");
 }
?>