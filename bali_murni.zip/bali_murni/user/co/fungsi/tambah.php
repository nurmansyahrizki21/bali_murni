<?php
function tambah($data){
    $y = date('Y');
    $m = date('m');
    $d = date('d');
    $s = date('s');
    $time = date('H:i:s');
    global $conn;
    $id_co=$data['id_co'];
    $tgl=$data['tgl'];
    $id_pelanggan=$data['id_pelanggan'];
    
    $tambah = mysqli_query($conn,"INSERT INTO co values('','$id_co','$tgl','$id_pelanggan','0','')");
    $tambah2 = mysqli_query($conn,"INSERT INTO detail_co SELECT * FROM detail_co_tmp");
    $delete  = mysqli_query($conn,"DELETE FROM detail_co_tmp");
    
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Menambah Confirmation Order!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=co";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah Confirmation Order!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=co";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>