<?php
  if (!empty($_GET['p'])) {
      if($_GET['p'] == 'dashboard_marketing'){
          include "dashboard_marketing.php";
      }else if($_GET['p'] == 'dashboard_akunting'){
        include "dashboard_akunting.php";
      }else if($_GET['p'] == 'dashboard_direktur'){
        include "dashboard_direktur.php";
      }else if($_GET['p'] == 'user'){
        include "user/user.php";
      }else if($_GET['p'] == 'tambah_user'){
          include "user/tambah_user.php";
      }else if($_GET['p'] == 'ubah_user'){
        include "user/ubah_user.php";
      }else if($_GET['p'] == 'pelanggan'){
        include "pelanggan/pelanggan.php";
      }else if($_GET['p'] == 'tambah_pelanggan'){
        include "pelanggan/tambah_pelanggan.php";
      }else if($_GET['p'] == 'ubah_pelanggan'){
        include "pelanggan/ubah_pelanggan.php";
      }else if($_GET['p'] == 'barang'){
        include "barang/barang.php";
      }else if($_GET['p'] == 'tambah_barang'){
        include "barang/tambah_barang.php";
      }else if($_GET['p'] == 'co'){
        include "co/data_co.php";
      }else if($_GET['p'] == 'po'){
        include "po/data_po.php";
      }else if($_GET['p'] == 'penjualan'){
        include "penjualan/data_penjualan.php";
      }else if($_GET['p'] == 'tambah_barang'){
        include "barang/tambah_barang.php";
      }else if($_GET['p'] == 'ubah_barang'){
        include "barang/ubah_barang.php";
      }else if($_GET['p'] == 'laporan'){
        include "laporan/laporan.php";
      }else if($_GET['p'] == 'laporan_penjualan'){
        include "laporan/laporan_penjualan.php";
      }else if($_GET['p'] == 'laporan_pembelian'){
        include "laporan/laporan_pembelian.php";
      }else if($_GET['p'] == 'laporan_persediaan_barang'){
        include "laporan/laporan_persediaan_barang.php";
      }else{
         include "404.html";
      }
  }
?>