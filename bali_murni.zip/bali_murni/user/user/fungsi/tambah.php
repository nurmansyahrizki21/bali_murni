<?php

function tambah($data){
    global $conn;
    $id_user=$data['id_user'];
    $nama_user=$data['nama_user'];
    $username=$data['username'];
    $password=$data['password'];
    $jabatan=$data['jabatan'];
    $tambah = mysqli_query($conn,"INSERT INTO user values('','$id_user','$nama_user','$username','$password','$jabatan')");
    return $tambah;
}

if(isset($_POST['simpan'])){
    if( tambah($_POST) > 0){
            echo 
            '<script>
                swal({ title: "Berhasil",
                text: "Menambah User!",
                type: "success"}).then(okay => {
                if (okay) {
                window.location.href = "?p=user";
                    }
                });
            </script>';
        } else {
            echo '
            <script>
                swal({ title: "Gagal",
                text: "Menambah User!",
                type: "error"}).then(okay => {
                if (okay) {
                window.location.href = "?p=user";
                    }
                });
            </script>';
            echo "<br>";
        }
    }        
?>