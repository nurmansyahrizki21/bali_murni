<?php

 if(isset($_GET['id'])){
    $id=$_GET['id'];

    function getData($query){
        global $conn;
        $sql = mysqli_query($conn,$query);
        $getData = mysqli_fetch_array($sql);
        return $getData;
    }

    $getDataId = getData("SELECT * from user WHERE id ='$id'");
    
    function seeData($key){
        global $getDataId;
        $see = $getDataId[$key];
        return $see;
    } 
    
    }else{
        function seeData($key){
        $see = '';
    } 
  }

  function ubah($data){
    global $conn;
    $id=$data['id'];
    $id_user=$data['id_user'];
    $nama_user=$data['nama_user'];
    $username=$data['username'];
    $password=$data['password'];
    $jabatan=$data['jabatan'];

    $ubah = mysqli_query($conn,"UPDATE user SET
                            id_user = '$id_user',
                            nama_user = '$nama_user',
                            username = '$username',
                            password = '$password',
                            jabatan = '$jabatan'
                            WHERE id = '$id'");
    return $ubah;
}

  
if(isset($_POST['ubah'])){
    if (ubah($_POST) > 0){
        echo 
        '<script>
            swal({ title: "Berhasil",
            text: "Mengubah User!",
            type: "success"}).then(okay => {
            if (okay) {
            window.location.href = "?p=user";
                }
            });
        </script>';
        }else{
        echo '
        <script>
            swal({ title: "Gagal",
            text: "Mengubah User!",
            type: "error"}).then(okay => {
            if (okay) {
            window.location.href = "?p=user";
                }
            });
        </script>';
        echo "<br>";
        }
    }       

?>