<?php include 'fungsi.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h4><i class="fa fa-user"></i> Data User</h4>
            <div class="card">
                <div class="card-header">
                <a href="?p=tambah_user" class="btn btn-primary"><i class="fa fa-plus"></i>  Tambah</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first" id="cari">
                            <thead>
                                <tr>
                                    <th>Id User</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no=1;
                                $query="SELECT * FROM user";
                                $sql=mysqli_query($conn, $query);
                                while ($data=mysqli_fetch_array($sql)) {
                                    if($data['jabatan']==2){
                                        $jabatan = 'Marketing';
                                    }else if($data['jabatan']==1){
                                        $jabatan = 'Direktur';
                                    }else{
                                        $jabatan = 'Akunting';
                                    }
                                ?>
                            <tr>
                                <td><?php echo $data['id_user'];?></td>
                                <td><?php echo $data['nama_user'];?></td>
                                <td><?php echo $jabatan;?></td>
                                <td><?php echo $data['username'];?></td>
                                <td><?php echo '***********';?></td>
                                <td>  
                                <a href="?p=ubah_user&id=<?php echo $data['id'];?>" class="btn btn-primary btn-sm" style="margin-bottom: 2px;"><i class="fa fa-edit"></i> Ubah</a> 
                            </td>
                            </tr>  
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'modal.php';?>