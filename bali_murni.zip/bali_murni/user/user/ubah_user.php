<?php include 'fungsi/ubah.php';?>
<div class="card-home container-fluid">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="card-header">
                <h5><i class="fa fa-user"> Ubah Data User</i></h5>
                </div>
                <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data" style="margin-left:80px;">
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Id User</label>
                        <div class="col-sm-8">
                            <input type="hidden" name="id" value="<?php echo seeData('id'); ?>">
                            <input type="text" class="form-control" name="id_user" id="inputPassword3" value="<?php echo seeData('id_user'); ?>" required=""
                            oninvalid="this.setCustomValidity('Id User Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nama_user" id="inputPassword3" value="<?php echo seeData('nama_user'); ?>" required=""
                             oninvalid="this.setCustomValidity('Nama Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Jabatan</label>
                        <div class="col-sm-8">
                            <select class="form-control" name="jabatan" id="">
                                <option value="1" <?php if(seeData('jabatan')=='1'){?> selected <?php } ?>>Direktur</option>
                                <option value="2" <?php if(seeData('jabatan')=='2'){?> selected <?php } ?>>Marketing</option>
                                <option value="3" <?php if(seeData('jabatan')=='3'){?> selected <?php } ?>>Akunting</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Username</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="username" id="inputPassword3" value="<?php echo seeData('username'); ?>" required=""
                            oninvalid="this.setCustomValidity('Username Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control" name="password" id="inputPassword3" value="<?php echo seeData('password'); ?>" required=""
                            oninvalid="this.setCustomValidity('Password Tidak Boleh Kosong !')"oninput="setCustomValidity('')" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <div class="col-sm-12">
                                <a href="?p=user" class="btn btn-danger float-right ">BATAL</a>
                            </div>
                            <div class="col-sm-11">
                                <button type="submit" name="ubah" class="btn btn-primary float-right mr-2">SIMPAN</button>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>