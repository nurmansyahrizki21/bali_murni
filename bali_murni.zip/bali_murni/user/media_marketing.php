<?php 
session_start();
error_reporting(0);
if (empty($_SESSION[username]) AND empty($_SESSION[password])){
    echo"<script> alert('Hey, Login Dulu lah Sobat..');
  document.location.href = 'index.php'</script>";
}else{
    function rupiah($angka){
        $hasil_rupiah = "Rp " . number_format($angka,0,',','.');
        return $hasil_rupiah;
    };
?>
<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Raih kesuksesan bersama Forsage Indonesia Dream Team">
        <meta name="keywords" content="Forsage, Forsage Indonesia, Dream Team, Forsage Dream Team, Crypto, Bisnis, Sukses, Bisnis Online 2020">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <!-- Custom fonts for this template -->
        <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="../fonts/font-awesome-4.7.0/css/all.css" rel="stylesheet">
        <!-- LightBox2 Css-->
        <link rel="stylesheet" href="css/lightbox.min.css">
        <!-- LightBox2 Js -->
        <script src="js/lightbox-plus-jquery.min.js"></script>
        <!-- Aos -->
        <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
        <!-- Sweet Alert -->
        <script src="../plugins/sweetalert/sweetalert.all.min.js"></script>
        <link rel='stylesheet' href='../plugins/sweetalert/sweetalert.min.css'>
        <!-- Data Table -->
        <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
        <!-- My CSS -->
        <link rel="stylesheet" href="css/desktop/sidebar.css">
        <link rel="stylesheet" href="css/phone/style.css">
        <link rel="icon" href="../images/logo.png">
        <title>Hansgroe | Marketing</title>
    </head>
    <body>
    <?php include 'config/koneksi.php';
     if (!empty($_GET['p'])) {
        $menu = $_GET['p'];
     }

     $xx = 10;
 
    ?>
    <div class="d-flex" id="wrapper">

        <!-- Sidebar -->
        <div class="bg-dark border-right" id="sidebar-wrapper">
            <div class="sidebar-heading"><img src="../logo/logo.png" alt="" width="150">
            </div>
            <div class="sidebar-heading2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 ml-2 mt-3">
                            <i class="fa fa-circle" style="color:green;"></i>
                        </div>
                        <div class="col-md-3 mt-3 mb-2" style="margin-left:-35px;">
                            <h6 class="online">Online</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="list-group list-group-flush">
                <a href="?p=dashboard_marketing" <?php if($menu == 'dashboard_marketing'){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"><i class="fa fa-home"></i> Dashboard</a>
                <a href="?p=pelanggan" <?php if($menu == 'pelanggan' || $menu == 'tambah_pelanggan' || $menu == 'ubah_pelanggan' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?>><i class="fa fa-building"></i> Pelanggan</a>
                <a href="?p=co" <?php if($menu == 'co'){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"><i class="fa fa-copy"></i> Confirmation Order</a>
                <a href="?p=po" <?php if($menu == 'po'){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"><i class="fa fa-file"></i> Purcahase Order</a>
                <a href="?p=penjualan" <?php if($menu == 'penjualan' || $menu == 'tambah_pengeluaran' || $menu == 'ubah_pengeluaran' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"><i class="fa fa-credit-card"></i> Transaksi Penjualan</a>
                <a href="?p=laporan" <?php if($menu == 'laporan' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"><i class="fa fa-file"></i> Laporan</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-brand" href="#">PT BALI MURNI</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-user"></i> Marketing
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </li>
                    <li class="nav-link d-block d-sm-none">
                        <a href="?p=dashboard_marketing" <?php if($menu == 'dashboard_marketing'){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark"> Dashboard</a>
                    </li>    
                    <li class="nav-link d-block d-sm-none">
                        <a href="?p=user" <?php if($menu == 'user' || $menu == 'tambah_user' || $menu == 'ubah_user' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark">user</a>
                   </li>
                    <li class="nav-link d-block d-sm-none">
                        <a href="?p=pelanggan" <?php if($menu == 'pelanggan' || $menu == 'tambah_pelanggan' || $menu == 'ubah_pelanggan' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?>> pelanggan</a>
                        <!-- <a href="#" class="list-group-item list-group-item-action bg-dark">Promo</a> -->
                    </li>
                    <li class="nav-link d-block d-sm-none">
                        <a href="?p=booking" <?php if($menu == 'booking'){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark">Booking</a>
                    </li>
                    <li class="nav-link d-block d-sm-none"> 
                        <a href="?p=pengeluaran" <?php if($menu == 'pengeluaran' || $menu == 'tambah_pengeluaran' || $menu == 'ubah_pengeluaran' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark">Pengeluaran</a>
                    </li> 
                    <li class="nav-link d-block d-sm-none"> 
                        <a href="?p=laba_rugi" <?php if($menu == 'laba_rugi' ){?> class="list-group-item list-group-item-action active" <?php }else{?> class="list-group-item list-group-item-action bg-dark" <?php } ?> class="list-group-item list-group-item-action bg-dark">Laporan Laba Rugi</a>
                    </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                    <ul class="navbar-nav mr-auto">
                
                    </ul>
                    </form>
                </div>
            </nav>
           <?php include 'content.php';?>
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    <!-- /#wrapper -->

    <!-- Bootstrap core JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Data Table -->
    <script src="../plugins/datatables/jquery.dataTables.js"></script>
    <script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
    
    <!-- Fungsi Cari Data -->
    <script>
        $(function () {
            $("#cari").DataTable();
            $('#cari2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            });
        });
    </script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
    });
    </script>

    <?php include '../ajax.php';?>

    </body>  
</html>
<?php } ?>