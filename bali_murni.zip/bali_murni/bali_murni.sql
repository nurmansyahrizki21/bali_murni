/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.3.15-MariaDB : Database - bali_murni
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bali_murni` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bali_murni`;

/*Table structure for table `barang` */

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang` varchar(25) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `nama_barang` varchar(25) DEFAULT NULL,
  `tipe_barang` varchar(25) DEFAULT NULL,
  `deskripsi` varchar(50) DEFAULT NULL,
  `harga_beli` float DEFAULT NULL,
  `harga_jual` float DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `barang` */

insert  into `barang`(`id`,`id_barang`,`tgl`,`nama_barang`,`tipe_barang`,`deskripsi`,`harga_beli`,`harga_jual`,`jumlah`) values (1,'7190012','2021-03-09','Wash Bowl','AX Urquiola','Wash Bowl 500mm mineral moulded',750000,1500000,30),(2,'7190013','2021-03-09','Shower','AX Urquiola','Shower Mantap Jiwa',500000,1300000,35),(3,'BRG811','2021-05-01','Bathup','AX Urquiola','Bathup luxury mevah',6500000,10000000,0);

/*Table structure for table `co` */

DROP TABLE IF EXISTS `co`;

CREATE TABLE `co` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_co` varchar(15) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `id_pelanggan` varchar(15) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `surat_jalan` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

/*Data for the table `co` */

insert  into `co`(`id`,`id_co`,`tgl`,`id_pelanggan`,`status`,`surat_jalan`) values (30,'INV202105011','2021-05-01','PE001',1,'SJ-31/05/2021');

/*Table structure for table `detail_co` */

DROP TABLE IF EXISTS `detail_co`;

CREATE TABLE `detail_co` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_co` varchar(50) DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;

/*Data for the table `detail_co` */

insert  into `detail_co`(`id`,`id_co`,`id_barang`,`jumlah`,`total_harga`) values (26,'INV202105011','7190012',10,15000000),(27,'INV202105011','7190013',15,19500000),(28,'INV202105011','BRG811',5,50000000);

/*Table structure for table `detail_co_tmp` */

DROP TABLE IF EXISTS `detail_co_tmp`;

CREATE TABLE `detail_co_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_co` varchar(50) DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `detail_co_tmp` */

/*Table structure for table `detail_po` */

DROP TABLE IF EXISTS `detail_po`;

CREATE TABLE `detail_po` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_po` varchar(50) DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

/*Data for the table `detail_po` */

insert  into `detail_po`(`id`,`id_po`,`id_barang`,`jumlah`,`total_harga`) values (142,'PO202105011','BRG811',5,32500000);

/*Table structure for table `detail_po_tmp` */

DROP TABLE IF EXISTS `detail_po_tmp`;

CREATE TABLE `detail_po_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_po` varchar(50) DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

/*Data for the table `detail_po_tmp` */

/*Table structure for table `mutasi_persediaan` */

DROP TABLE IF EXISTS `mutasi_persediaan`;

CREATE TABLE `mutasi_persediaan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl` date DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `stok_awal` int(11) DEFAULT NULL,
  `masuk` int(11) DEFAULT NULL,
  `keluar` int(11) DEFAULT NULL,
  `stok_akhir` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

/*Data for the table `mutasi_persediaan` */

insert  into `mutasi_persediaan`(`id`,`tgl`,`id_barang`,`stok_awal`,`masuk`,`keluar`,`stok_akhir`) values (21,'2021-05-01','BRG811',0,5,0,5),(22,'2021-05-01','7190012',40,0,10,30),(23,'2021-05-01','7190013',50,0,15,35),(24,'2021-05-01','BRG811',5,0,5,0);

/*Table structure for table `pelanggan` */

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pelanggan` varchar(15) DEFAULT NULL,
  `nama_pelanggan` varchar(25) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_pelanggan` (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `pelanggan` */

insert  into `pelanggan`(`id`,`id_pelanggan`,`nama_pelanggan`,`alamat`,`no_telp`,`email`) values (1,'PE001','Hotel Bulgari','Denpasar','081999128111','indri@gmail.com'),(2,'PE002','Hotel Des Indische','Denpasar','098121111','ardi@gmail.com');

/*Table structure for table `penjualan` */

DROP TABLE IF EXISTS `penjualan`;

CREATE TABLE `penjualan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_penjualan` varchar(50) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `id_barang` varchar(25) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  `id_pelanggan` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `penjualan` */

/*Table structure for table `po` */

DROP TABLE IF EXISTS `po`;

CREATE TABLE `po` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_po` varchar(15) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

/*Data for the table `po` */

insert  into `po`(`id`,`id_po`,`tgl`,`status`) values (19,'PO202105011','2021-05-01',0);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(10) DEFAULT NULL,
  `nama_user` varchar(5) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `jabatan` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`id_user`,`nama_user`,`username`,`password`,`jabatan`) values (1,'10001','rizki','direktur','1234',2),(4,'10002','deas','marketing','1234',3),(6,'10003','indah','akunting','1234',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
